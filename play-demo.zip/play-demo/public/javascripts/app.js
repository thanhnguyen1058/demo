var clientApp = angular.module("clientApp", []);

clientApp.controller('clientAppCtrl', function ($scope, $http, $log) {
	
	$scope.personToAdd = {
		name: "",
		email: ""
	}
	
	$scope.existingPersons = [];
	
	$scope.initialize = function(){
		$scope.getPersons();
	}
	
	$scope.personToView = {
		name: "",
		email: ""
	}
	
	$scope.viewDetails = function(person) {
		$scope.personToView.name = person.name;
  	  	$scope.personToView.email = person.email;
	}
	
	$scope.addPerson = function() {
	  var errorMessage = null;
	  if ($scope.personToAdd.name == "") {
		  errorMessage = "Please enter name.";
	  }
	  else if ($scope.personToAdd.email == "") {
		  errorMessage = "Please enter email.";
	  }
	  if (errorMessage == null) {
		  if (!$scope.checkForExistingName($scope.personToAdd.name)) {
			  $http.post('/addPerson', $scope.personToAdd)
		          .success(function(data) {
		        	  $log.debug("Save Successfully");
		        	  $scope.getPersons();
		          }).
		          error(function(data, status, headers, config) {
		          	$log.debug("Save Error ");
				 });
		  }
		  else {
			  alert("Name already exists.")
		  }
	  }
	  else {
		  alert(errorMessage);
	  }
    };
    
    $scope.checkForExistingName = function(name) {
    	var exist = false;
    	if ($scope.existingPersons != null && $scope.existingPersons.length > 0) {
    		for (var i = 0; i < $scope.existingPersons.length; i++) {
    			var person = $scope.existingPersons[i];
    			person.checked = false;
    			if (person.name == name) {
    				exist = true;
    				break;
    			}
    		}
    	}
    	return exist;
    }
    
    $scope.clearFields = function() {
    	$scope.personToAdd.name = "";
  	  	$scope.personToAdd.email = "";
  	  	$scope.personToView.name = "";
  	  	$scope.personToView.email = "";
    }
    
    $scope.getPersons = function() {
    	$scope.existingPersons = [];
        $http.get('/getPersons')
            .success(function(data) {
            	if (data != null && data.length > 0) {
            		for (var i = 0; i < data.length; i++) {
            			var person = data[i];
            			person.checked = false;
            			$scope.existingPersons.push(person);
            		}
            		$scope.clearFields();
            		$log.debug("getting data successfully: ");
            	}
            }).
            error(function(data, status, headers, config) {
            	$log.debug("Error in getting data");
		 });
    };
    
    $scope.deletePersons = function() {
    	var deleteRequest = {names: []};
    	for (var i = 0; i < $scope.existingPersons.length; i++) {
    		var person = $scope.existingPersons[i];
    		if (person.checked) {
    			deleteRequest.names.push(person.name);
    		}
    	}
    	if (deleteRequest.names.length > 0) {
    		var result = confirm("Want to delete?");
    		if (result) {
    			$http.post('/deletePersons', deleteRequest)
 	            	.success(function(data) {
 	            		$log.debug("Delete successfully");
 	            		$scope.getPersons();
 	            	}).
 	            	error(function(data, status, headers, config) {
 	            		$log.debug("Delete Error ");
 	            	});
    		}
    	}
    	else {
    		alert("No person selected for delete");
    	}
    };
});