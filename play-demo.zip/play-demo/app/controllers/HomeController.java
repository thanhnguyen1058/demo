package controllers;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.mongodb.morphia.query.Query;
import com.fasterxml.jackson.databind.JsonNode;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
//import com.mongodb.WriteConcern;
import models.Person;
import play.mvc.*;
import services.MongoConfig;
import views.html.*;
import static play.libs.Json.toJson;

/**
 * This controller contains an action to handle HTTP requests
 * to the application's home page.
 */
public class HomeController extends Controller {

    /**
     * An action that renders an HTML page with a welcome message.
     * The configuration in the <code>routes</code> file means that
     * this method will be called when the application receives a
     * <code>GET</code> request with a path of <code>/</code>.
     */
    public Result index() {
        return ok(index.render("Welcome to User Entry Application."));
    }

    public Result addPerson() {
    	JsonNode json = request().body().asJson();
	    if (json == null) {
	        return badRequest("Expecting Json data");
	    } else {
	        String name = json.findPath("name").textValue();
	        String email = json.findPath("email").textValue();
	        if(name == null || email == null) {
	            return badRequest("Missing parameters: name and email");
	        } else {
	        	Person person = new Person();
	        	person.setName(name);;
	        	person.setEmail(email);
	        	MongoConfig.datastore().save(person);
	            return ok("Save Successful ");
	        }
	    }
    }
    
    public Result getPersons() {
    	DBCollection dbCollection = MongoConfig.datastore().getCollection(Person.class);
    	DBCursor cursor = dbCollection.find();
    	List<BasicDBObject> persons = new ArrayList<BasicDBObject>();
    	while (cursor.hasNext()) {
    		 BasicDBObject person = (BasicDBObject) cursor.next();
    		 persons.add(person);
    	}
    	return ok(toJson(persons));
    }
    
    public Result deletePersons() {
    	JsonNode json = request().body().asJson();
	    if (json == null) {
	        return badRequest("Expecting Json data");
	    } else {
	    	JsonNode namesNode = json.findPath("names");
	    	if (namesNode != null) {
	    		Iterator<JsonNode> nameElements = namesNode.elements();
	    		while (nameElements.hasNext()) {
	    			JsonNode nameNode = nameElements.next();
	    			Query<Person> query = MongoConfig.datastore().createQuery(Person.class)
	                        .field("name").equal(nameNode.textValue());
	    	    	MongoConfig.datastore().findAndDelete(query);
	    		}
	    		return ok("Delete Successful ");
	    	}
	    	else {
	    		return badRequest("Expecting Json data");
	    	}
	    }
    }
}
